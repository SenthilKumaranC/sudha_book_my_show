import styled from "styled-components";

export const CustomButton = styled.button`
  color: red;
  width: 100px;
  height: 300px;
  background-color: black;
`;
