import { useContext } from "react";
import styled from "styled-components";
import { CustomButton } from "../../BasicComponents/CustomButton";
import { TicketPlatformContext } from "../OnlineTicketPlatform/OnlineTicketPlatform";

const MoviesSelection = () => {
  const { state } = useContext(TicketPlatformContext);

  const { movieList } = state;

  return (
    <>
      <label>Pick a movie:</label>
      <select id="movie">
        {movieList.map((singleMovie) => {
          return (
            <option value={singleMovie.id} key={singleMovie.id}>
              {singleMovie.movieName} (₹{singleMovie.ticketPrice})
            </option>
          );
        })}
      </select>
    </>
  );
};

export default MoviesSelection;
