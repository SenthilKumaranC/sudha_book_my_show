import Legends from "../Legends/Legends";
import MoviesSelection from "../MoviesSelection/MoviesSelection";
import Seats from "../Seats/Seats";
import TotalPriceInfo from "../TotalPriceInfo/TotalPriceInfo";
import classes from "./OnlineTicketPlatform.module.css";

import MovieListJson from "../../data/movieslist.json";
import { useReducer } from "react";
import React from "react";

export interface IMovie {
  id: string;
  movieName: string;
  ticketPrice: number;
}

export interface ITicketPlatform {
  movieList: IMovie[];
}

export const Actions = {
  ON_MOVIE_SELECTED: "ON_MOVIE_SELECTED",
};

const initialState: ITicketPlatform = {
  movieList: MovieListJson,
};

const reducer = (state: ITicketPlatform, action: any) => {
  switch (action.type) {
    case Actions.ON_MOVIE_SELECTED:
      return { ...state };
    default:
      return state;
  }
};

export interface ITicketPlatformContext{
    state:ITicketPlatform,
    dispatch:any
}

export const TicketPlatformContext = React.createContext<ITicketPlatformContext>({
  state: initialState,
  dispatch: (data: any) => {},
});

const OnlineTicketPlatform = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <TicketPlatformContext.Provider value={{ state, dispatch }}>
      <div className={classes.MovieContainer}>
        <MoviesSelection></MoviesSelection>
        <Legends></Legends>
        <Seats></Seats>
        <TotalPriceInfo></TotalPriceInfo>
      </div>
    </TicketPlatformContext.Provider>
  );
};

export default OnlineTicketPlatform;
